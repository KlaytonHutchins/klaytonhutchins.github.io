package com.skilldistillery.quiz.data;

public interface PlanetDAO {
  Planet getPlanetByName(String name);
}

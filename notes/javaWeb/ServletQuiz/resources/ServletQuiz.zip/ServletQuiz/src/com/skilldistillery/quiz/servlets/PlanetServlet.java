package com.skilldistillery.quiz.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.skilldistillery.quiz.data.InMemoryPlanetDAOImpl;
import com.skilldistillery.quiz.data.PlanetDAO;

public class PlanetServlet extends HttpServlet {
  
  private PlanetDAO dao;

  @Override
  public void init() throws ServletException {
    super.init();
    dao = new InMemoryPlanetDAOImpl();
  }

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    // 1. Get the request parameter "pname"
    String pNameValue = null;
    
    // 2. Use pNameValue to get a planet by name from the dao
    
    // 3. If the planet from the DAO is not null, add it to the model with the key "planet"
    
    // 4. Select and forward to the JSP view "/WEB-INF/planetinfo.jsp"
    
  }

  
}

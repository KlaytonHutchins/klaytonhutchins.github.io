DROP DATABASE IF EXISTS historydb;

CREATE DATABASE IF NOT EXISTS historydb;

DROP USER IF EXISTS historyuser;

CREATE USER IF NOT EXISTS historyuser@localhost IDENTIFIED BY 'historyuser';

GRANT SELECT, INSERT, UPDATE, DELETE on historydb.* TO historyuser@localhost;

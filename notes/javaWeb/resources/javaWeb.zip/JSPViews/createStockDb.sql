DROP DATABASE IF EXISTS stockdb;

CREATE DATABASE IF NOT EXISTS stockdb;

DROP USER IF EXISTS stockuser;

CREATE USER IF NOT EXISTS stockuser@localhost IDENTIFIED BY 'stockuser';

GRANT SELECT, INSERT, UPDATE, DELETE on stockdb.* TO stockuser@localhost;



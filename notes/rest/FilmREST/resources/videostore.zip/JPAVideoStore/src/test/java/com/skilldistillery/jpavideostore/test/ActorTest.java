package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.entities.Actor;

class ActorTest {
	private EntityManagerFactory emf;
	private EntityManager em;
	private Actor actor;

	@BeforeEach
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
		actor = em.find(Actor.class, 1);
	}

	@Test
	void test_actor_mappings() {
		assertEquals("Penelope", actor.getFirstName());
		assertEquals("Guiness", actor.getLastName());
	}
	
	@Test
	void test_actor_to_film() {
		assertEquals("ANACONDA CONFESSIONS", actor.getFilms().get(0).getTitle());
	}

	@AfterEach
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}
}

package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.client.JPQLLab;

class JPQLTest {
	private JPQLLab lab;
	
	@BeforeEach
	public void setUp() throws Exception {
		lab = new JPQLLab();
	}
	
	@Test
	void test_getRangeOfCustomers() {
		assertEquals(11, lab.getRangeOfCustomers(100, 110).size());
		assertEquals(100, lab.getRangeOfCustomers(100, 110).get(0).getId());
		assertEquals(109, lab.getRangeOfCustomers(100, 110).get(9).getId());
	}
	
	@Test
	void test_getCustomerEmailByName() {
		assertEquals("MARY.SMITH@sdvidcustomer.org", lab.getCustomerEmailByName("Mary", "Smithers"));
		assertNull(lab.getCustomerEmailByName("Get", "Null"));
	}
	
	@Test
	void test_getFilmByTitle() {
		assertEquals("ACADEMY DINOSAUR", lab.getFilmByTitle("ACADEMY DINOSAUR").getTitle());
		assertNull(lab.getFilmByTitle("NULL TITLE"));
	}
	
	@Test
	void test_getFilmsTitlesByReleaseYear() {
		assertEquals(30, lab.getFilmsTitlesByReleaseYear(2000).size());
	}

}

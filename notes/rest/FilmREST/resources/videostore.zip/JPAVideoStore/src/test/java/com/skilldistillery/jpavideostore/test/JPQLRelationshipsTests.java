package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.client.JPQLRelationshipsLab;

@DisplayName("JPQL Relationships Lab")
class JPQLRelationshipsTests {
	private JPQLRelationshipsLab lab;
	
	@BeforeEach
	void setup() {
		lab = new JPQLRelationshipsLab();
	}
	
	@Test
	void test_getStoresByState() {
		assertEquals(1, lab.getStoresByState("Washington").size());
	}
	
	@Test
	void test_getRentalsForCustomerWithCustomerId() {
		assertEquals(95, lab.getRentalsForCustomerWithCustomerId(1).size());
	}
	
	@Test
	void test_getFilmsForActorWithId() {
		assertEquals("ACADEMY DINOSAUR", lab.getFilmsForActorWithId(1).get(0).getTitle());
	}
	
	@Test
	void test_getNumberOfFilmsForCategoryWithName() {
		assertEquals(58, lab.getNumberOfFilmsForCategoryWithName("Comedy"));
	}
	
	@Test
	void test_getInventoryForStoreWithId() {
		assertEquals("ACADEMY DINOSAUR", lab.getInventoryForStoreWithId(1).get(0).getTitle());
	}
}

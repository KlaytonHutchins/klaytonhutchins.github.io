package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.entities.InventoryItem;
import com.skilldistillery.jpavideostore.entities.MediaCondition;

@DisplayName("Inventory Item Entity Test")
class InventoryItemTest {

	private EntityManagerFactory emf;
	private EntityManager em;
	private InventoryItem item;

	@BeforeEach
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
		item = em.find(InventoryItem.class, 1);

	}

	@Test
	void test_II_mappings() {
		assertEquals(MediaCondition.Used, item.getCondition());
	}
	
	@Test
	void test_II_to_film() {
		assertEquals("ACADEMY DINOSAUR", item.getFilm().getTitle());
	}
	
	@Test
	void test_II_to_store() {
		assertEquals("Dutch", item.getStore().getManager().getFirstName());
	}

	@Test
	void test_II_to_rental() {
		assertEquals(3, item.getRentals().size());
	}
	
	@AfterEach
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}
}

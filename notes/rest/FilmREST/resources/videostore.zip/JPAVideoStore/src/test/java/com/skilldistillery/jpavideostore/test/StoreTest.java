package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.entities.Store;

@DisplayName("Store Entity Tests")
class StoreTest {

	private EntityManagerFactory emf;
	private EntityManager em;
	Store store;

	@BeforeEach
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
		store = em.find(Store.class, 1);
	}

	@Test
	void test_store_mappings() {
		assertEquals(1, store.getId());
	}
	
	@Test
	void test_store_to_address() {
		assertEquals("Seattle", store.getAddress().getCity());
	}
	
	@Test
	void test_store_to_customer() {
		assertEquals(74, store.getCustomers().size());
	}
	
	@Test
	void test_store_to_staffMembers() {
		assertEquals(16, store.getStaffMembers().size());
	}
	
	@Test
	void test_store_to_manager() {
		assertEquals("Dutch", store.getManager().getFirstName());
	}
	
	@Test
	void test_store_to_film() {
		assertEquals("AGENT TRUMAN", store.getFilms().get(0).getTitle());
	}
	
	@Test
	void test_store_to_InvItem() {
		assertEquals(2270, store.getCopies().size());
	}

	@AfterEach
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}
}

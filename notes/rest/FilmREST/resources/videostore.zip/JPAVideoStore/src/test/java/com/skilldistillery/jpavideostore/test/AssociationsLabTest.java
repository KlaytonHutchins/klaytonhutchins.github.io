package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.client.JPQLRelationshipsLab;

@DisplayName("Association Class Test")
class AssociationsLabTest {
	private JPQLRelationshipsLab lab;
	
	@BeforeEach
	void setup() {
		lab = new JPQLRelationshipsLab();
	}
	
	@Test
	void test_checkFilmInventoryItemsForStoreById() {
		assertEquals(4, lab.checkFilmInventoryItemsForStoreById(1, "ACADEMY DINOSAUR"));
	}

	@Test
	void test_getFilmsRentedForCustomerWithId() {
		assertEquals("GRIT CLOCKWORK", lab.getFilmsRentedForCustomerWithId(1).get(0).getTitle());
	}
}

package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.entities.Address;
import com.skilldistillery.jpavideostore.entities.Customer;

@DisplayName("Customer Entity Tests")
class CustomerTest {
	private EntityManagerFactory emf;
	private EntityManager em;
	private Customer cust;

	@BeforeEach
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
		cust = em.find(Customer.class, 1);
	}

	@Test
	void test_customer_mappings() {
		assertEquals("Mary", cust.getFirstName());
		assertEquals("Smithers", cust.getLastName());
		assertEquals("MARY.SMITH@sdvidcustomer.org", cust.getEmail());
	}

	@Test
	void test_customer_temporal_annotations() {
		assertEquals("2014-05-25", cust.getCreatedAt().toString());
	}

	@Test
	void test_customer_to_address() {
	     Address address = cust.getAddress();
	     assertEquals("1913 Hanoi Way", address.getStreet());
	     assertEquals("", address.getStreet2());
	     assertEquals("Sasebo", address.getCity());
	     assertEquals("Nagasaki", address.getState());
	     assertEquals("35200", address.getPostalCode());
	}
	
	@Test
	void test_customer_to_rental() {
		assertEquals(95, cust.getRentals().size());
	}
	@Test
	void test_customer_to_store() {
		assertEquals("27340 El Camino Real", cust.getStore().getAddress().getStreet());
	}

	@AfterEach
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}
}

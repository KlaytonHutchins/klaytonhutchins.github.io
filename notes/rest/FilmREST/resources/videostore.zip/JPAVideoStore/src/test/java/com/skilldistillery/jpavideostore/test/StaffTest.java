package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.entities.Staff;

@DisplayName("Staff Entity Tests")
class StaffTest {

	private EntityManagerFactory emf;
	private EntityManager em;
	private Staff staff;

	@BeforeEach
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
		staff = em.find(Staff.class, 1);
	}

	@Test
	void test_staff_mappings() {
		assertEquals("larry.kong@example.com", staff.getEmail());
		assertEquals("Larry", staff.getFirstName());
		assertEquals("Kong", staff.getLastName());
	}

	@Test
	void test_staff_to_address() {
		assertEquals("Nevada", staff.getAddress().getState());
	}
	
	@Test
	void test_staff_to_store() {
		assertEquals("Nevada", staff.getStore().getAddress().getState());
	}
	
	@AfterEach
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}
}

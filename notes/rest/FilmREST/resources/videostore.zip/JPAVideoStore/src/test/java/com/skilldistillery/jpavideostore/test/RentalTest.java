package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.entities.Rental;

@DisplayName("Rental Entity Test")
class RentalTest {
	private EntityManagerFactory emf;
	private EntityManager em;
	private Rental rental;

	@BeforeEach
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
		rental = em.find(Rental.class, 1);
	}

	@Test
	void test_rental_mappings() {
		assertEquals(1, rental.getId());
	}
	
	@Test
	void test_rental_temporal_mappings() {
		assertEquals("2014-05-24", rental.getRentalDate().toString());
		assertEquals("2014-05-26", rental.getReturnDate().toString());
	}
	
	@Test
	void test_rental_to_staff() {
		assertEquals("William", rental.getStaff().getFirstName());
	}
	
	@Test
	void test_rental_to_customer() {
		assertEquals("Charlotte", rental.getCustomer().getFirstName());
	}
	
	@Test
	void test_rental_to_InvItem() {
		assertEquals("MONTEREY LABYRINTH", rental.getItem().getFilm().getTitle());
	}



	@AfterEach
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}

}

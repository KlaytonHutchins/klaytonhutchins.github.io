package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.entities.Film;
import com.skilldistillery.jpavideostore.entities.Rating;

@DisplayName("Film Entity Tests")
class FilmTest {
	private EntityManagerFactory emf;
	private EntityManager em;
	private Film film;

	@BeforeEach
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
		film = em.find(Film.class, 1);
	}

	@Test
	void test_film_mappings() {
		assertEquals("ACADEMY DINOSAUR", film.getTitle());
		assertEquals("A Epic Drama of a Feminist And a Mad Scientist who must Battle a Teacher in The Canadian Rockies", film.getDescription());
		assertEquals(86, film.getLength());
		assertEquals(1993, film.getReleaseYear());
		assertEquals(0.99, film.getRentalRate());
		assertEquals(20.99, film.getReplacementCost());
	}
	
	@Test
	void test_fims_have_ratings() {
		assertEquals(Rating.PG, film.getRating());
	}
	
	@Test
	void test_fims_to_language() {
		assertEquals("Japanese", film.getLanguage().getName());
	}
	
	@Test
	void test_fims_to_actor() {
		assertEquals("Penelope", film.getActors().get(0).getFirstName());
	}
	
	@Test
	void test_fims_to_category() {
		assertEquals("Documentary", film.getCategories().get(0).getName());
	}
	
	@Test
	void test_fims_to_store() {
		assertEquals("Dutch", film.getStores().get(0).getManager().getFirstName());
	}
	
	@Test
	void test_fims_to_InvItem() {
		assertEquals(28, film.getCopies().size());
	}
	
	@AfterEach
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}

}

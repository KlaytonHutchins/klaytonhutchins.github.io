package com.skilldistillery.jpavideostore.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.skilldistillery.jpavideostore.entities.Staff;

public class JPQLClient {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		/* Skill Drill 1 (basicQueries)
			String query = "SELECT s FROM Staff s WHERE s.id < 10";
			
			List<Staff> results = em.createQuery(query, Staff.class)
					.getResultList();
			
			for (Staff staff : results) {
				System.out.println(staff.getFirstName() + " " +staff.getLastName());
			}
		*/
		
		/* Skill Drill 2 (queryingForProperties)
			String query = "SELECT s.lastName FROM Staff s WHERE s.id < 10";
			
			List<String> results = em.createQuery(query, String.class)
					.getResultList();
			
			for (String lastName : results) {
				System.out.println(lastName);
			}
		*/
		
		/* Skill Drill 3 (retrieveMultipleProperties)
			String query = "SELECT s.firstName, s.lastName FROM Staff s WHERE s.id < 10";
			
			List<Object[]> results = em.createQuery(query, Object[].class)
					.getResultList();
			
			for (Object[] array : results) {
				System.out.println(array[0] + " " + array[1]);
			}
		*/
		
		/*Skill Drill 4 (queryParams)
		 	String query = "SELECT s.firstName, s.lastName FROM Staff s WHERE s.id < :id";
		
			List<Object[]> results = em.createQuery(query, Object[].class)
					.setParameter("id", 10)
					.getResultList();
			
			for (Object[] array : results) {
				System.out.println(array[0] + " " + array[1]);
			}
		 */

		
	}
}

package com.skilldistillery.jpavideostore.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.skilldistillery.jpavideostore.entities.Customer;
import com.skilldistillery.jpavideostore.entities.Film;

public class JPQLLab {
	public static void main(String[] args) {
		JPQLLab lab = new JPQLLab();
		
		lab.getRangeOfCustomers(100, 110); // #4
		lab.getCustomerEmailByName("Lary", "Kong"); // #5
		lab.getFilmByTitle("ACADEMY DINOSAUR"); // #6
		lab.getFilmsTitlesByReleaseYear(2000); // #6
	}
	
	public List<Customer> getRangeOfCustomers(int min, int max) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();
		
		String query = "SELECT c FROM Customer c WHERE c.id BETWEEN :min and :max";
		
		List<Customer> results = em.createQuery(query, Customer.class)
				.setParameter("min", min)
				.setParameter("max", max)
				.getResultList();
		
		for (Customer customer: results) {
			System.out.println(customer.getFirstName() + " " + customer.getLastName());
		}
		
		em.close();
		emf.close();
		
		return results;
	}
	
	public String getCustomerEmailByName(String fname, String lname) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();
		
		String email = null;
		
		String query = "SELECT c.email FROM Customer c WHERE c.firstName = :fname AND c.lastName = :lname";
		
		List<String> results = em.createQuery(query, String.class)
				.setParameter("fname", fname)
				.setParameter("lname", lname)
				.getResultList();
		
		
		if(results.size() > 0) {
			email = results.get(0);
		}
		
		System.out.println(email);
		
		em.close();
		emf.close();
		
		return email;
	}
	
	public Film getFilmByTitle(String title) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();
		
		Film film = null;
		
		String query = "SELECT f FROM Film f WHERE f.title= :title";
		
		List<Film> results = em.createQuery(query, Film.class)
				.setParameter("title", title)
				.getResultList();
		
		if(results.size() > 0) {
			film = results.get(0);
		}
		
		em.close();
		emf.close();
		
		return film;
	}
	
	public List<String> getFilmsTitlesByReleaseYear(int year){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();
				
		String query = "SELECT f.title FROM Film f WHERE f.releaseYear= :year";
		
		List<String> results = em.createQuery(query, String.class)
				.setParameter("year", year)
				.getResultList();
		
		for (String title : results) {
			System.out.println(title);
		}
		
		em.close();
		emf.close();
		
		return results;
	}
}

package com.skilldistillery.jpavideostore.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="inventory_item")
public class InventoryItem {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Enumerated(EnumType.STRING)
	@Column(name="media_condition")
	private MediaCondition condition;
	
	@ManyToOne
	@JoinColumn(name="film_id")
	private Film film;
	
	@ManyToOne
	@JoinColumn(name="store_id")
	private Store store;
	
	@OneToMany(mappedBy="item")
	private List<Rental> rentals;

	// gets and sets
	
	public int getId() {
		return id;
	}

	public MediaCondition getCondition() {
		return condition;
	}

	public void setCondition(MediaCondition condition) {
		this.condition = condition;
	}
	
	public Film getFilm() {
		return film;
	}

	public void setFilm(Film film) {
		this.film = film;
	}

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public List<Rental> getRentals() {
		return rentals;
	}

	public void setRentals(List<Rental> rentals) {
		this.rentals = rentals;
	}

	// add and remove from collections
	
	public void addRental(Rental r) {
		if(rentals == null) rentals= new ArrayList<>();
		
		if(!rentals.contains(r)) {
			rentals.add(r);
			if(r.getItem() != null) {
				r.getItem().getRentals().remove(r);
			}
			r.setItem(this);
		}
	}
	
	public void removeRental(Rental r) {
		r.setItem(null);
		if(rentals != null) {
			rentals.remove(r);
		}
	}
	
	// toString
	@Override
	public String toString() {
		return "InventoryItem [id=" + id + ", condition=" + condition + "]";
	}
	
	
}

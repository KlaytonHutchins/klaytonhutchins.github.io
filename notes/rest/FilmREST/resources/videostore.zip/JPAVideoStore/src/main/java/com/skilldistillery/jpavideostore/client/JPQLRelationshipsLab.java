package com.skilldistillery.jpavideostore.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.skilldistillery.jpavideostore.entities.Actor;
import com.skilldistillery.jpavideostore.entities.Category;
import com.skilldistillery.jpavideostore.entities.Customer;
import com.skilldistillery.jpavideostore.entities.Film;
import com.skilldistillery.jpavideostore.entities.InventoryItem;
import com.skilldistillery.jpavideostore.entities.Rental;
import com.skilldistillery.jpavideostore.entities.Store;

public class JPQLRelationshipsLab {
	public List<Store> getStoresByState(String state){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String query = "SELECT s FROM Store s WHERE s.address.state= :name";
		
		List<Store> results = em.createQuery(query, Store.class)
				.setParameter("name", state)
				.getResultList();
		
		em.close();
		emf.close();

		return results;
	}
	
	public List<Rental> getRentalsForCustomerWithCustomerId(int id){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String query = "SELECT c FROM Customer c JOIN FETCH c.rentals WHERE c.id= :id";
		
		Customer result = em.createQuery(query, Customer.class)
				.setParameter("id", id)
				.getResultList()
				.get(0);
		
		List<Rental> rentals = result.getRentals();
		
		em.close();
		emf.close();

		return rentals;
	}
	
	public List<Film> getFilmsForActorWithId(int id){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String query = "SELECT a FROM Actor a JOIN FETCH a.films WHERE a.id= :id";
		
		Actor result = em.createQuery(query, Actor.class)
				.setParameter("id", id)
				.getResultList()
				.get(0);
		
		List<Film> films = result.getFilms();
		
		em.close();
		emf.close();

		return films;
	}
	
	public int getNumberOfFilmsForCategoryWithName(String name) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String query = "SELECT c FROM Category c JOIN FETCH c.films WHERE c.name= :name";
		
		Category result = em.createQuery(query, Category.class)
				.setParameter("name", name)
				.getResultList()
				.get(0);
		
		int count = result.getFilms().size();
		
		em.close();
		emf.close();

		return count;
	}
	
	public List<Film> getInventoryForStoreWithId(int id){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String query = "SELECT s FROM Store s JOIN FETCH s.films WHERE s.id = :id";
		
		Store result = em.createQuery(query, Store.class)
				.setParameter("id", id)
				.getResultList()
				.get(0);
		
		List<Film> inventory= result.getFilms();
		
		em.close();
		emf.close();

		return inventory;
	}
	
	public int checkFilmInventoryItemsForStoreById(int id, String title) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String query = "SELECT i FROM InventoryItem i WHERE i.film.title = :title AND i.store.id = :id";
		
		List<InventoryItem> results = em.createQuery(query, InventoryItem.class)
				.setParameter("id", id)
				.setParameter("title", title)
				.getResultList();
		
		int count = results.size();
		
		em.close();
		emf.close();

		return count;
	}
	
	public List<Film> getFilmsRentedForCustomerWithId(int id) { 
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String query = "SELECT r.item.film FROM Rental r WHERE r.customer.id = :id";
		
		List<Film> results = em.createQuery(query, Film.class)
				.setParameter("id", id)
				.getResultList();		
				
		em.close();
		emf.close();

		return results;
	} 
}

package com.skilldistillery.jpavideostore.entities;

public enum MediaCondition {
	New, Used, Damaged, Lost, NA
}

package com.skilldistillery.jpavideostore.client;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.skilldistillery.jpavideostore.entities.Actor;
import com.skilldistillery.jpavideostore.entities.Address;
import com.skilldistillery.jpavideostore.entities.Customer;
import com.skilldistillery.jpavideostore.entities.Film;
import com.skilldistillery.jpavideostore.entities.Store;

public class RelationshipCRUDClient {
	
	public static void main(String[] args) {
		RelationshipCRUDClient relationshipCrud = new RelationshipCRUDClient();
		// running addNewActorToFilm
//		relationshipCrud.addNewActorToFilm();
//		System.out.println("It worked");
		
		//running newCustomerAndAddress
		relationshipCrud.newCustomerAndAddress();
		System.out.println("It worked");

	}
	
	public void addNewActorToFilm() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		Actor a = new Actor();
		a.setFirstName("Patrick");
		a.setLastName("Renna");
		
		em.getTransaction().begin();
		
		Film f = em.find(Film.class, 507);
		a.addFilm(f);
		
		em.persist(a);
		em.flush();
		
		em.getTransaction().commit();

				
		em.close();
		emf.close();
	}
	
	public void newCustomerAndAddress() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();
		
		Address a  = new Address();
		a.setStreet("1388 Glenrose Drive");
		a.setCity("Salt Lake City");
		a.setState("Utah");
		a.setPhone("3859273451");
		
		Customer c = new Customer();
		c.setFirstName("Wendy");
		c.setLastName("Peffercorn");
		c.setStore(em.find(Store.class, 6));
		c.setEmail("wendyPeffs@sdvidCustomer.org");
		c.setCreatedAt(new Date());
		c.setAddress(a);

		em.getTransaction().begin();

		em.persist(c);
		em.flush();
		
		em.getTransaction().commit();

		em.close();
		emf.close();
	}
	
}

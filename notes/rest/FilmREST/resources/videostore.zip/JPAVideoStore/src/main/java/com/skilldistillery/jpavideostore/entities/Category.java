package com.skilldistillery.jpavideostore.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Category {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	private String name;
	
	@ManyToMany(mappedBy="categories")
	private List<Film> films;

	// gets and sets
	
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<Film> getFilms() {
		return films;
	}


	public void setFilms(List<Film> films) {
		this.films = films;
	}

	// add and remove from a collection
	public void addFilm(Film f) {
		if(films == null) films = new ArrayList<>();
		
		if(!films.contains(f)) {
			films.add(f);
			f.addCategory(this);
		}
	}
	
	public void removeFilm(Film f) {
		if(films != null && films.contains(f)) {
			films.remove(f);
			f.removeCategory(this);
		}
	}
	
	// toString
	@Override
	public String toString() {
		return "Category [id=" + id + ", name=" + name + "]";
	}
	
	
}

package com.skilldistillery.jpavideostore.client;

import com.skilldistillery.jpavideostore.data.ActorDAOImpl;
import com.skilldistillery.jpavideostore.entities.Actor;
import com.skilldistillery.jpavideostore.entities.Film;

public class ActorDAOTest {
	public static void main(String[] args) {
		ActorDAOImpl actorDAO = new ActorDAOImpl();
		
		// create
//		Actor actorCreate = new Actor();
//		actorCreate.setFirstName("Andrew");
//		actorCreate.setLastName("Conlin");
//		actorCreate = actorDAO.create(actorCreate);
//		
//		System.out.println(actorCreate);
		 
		// update
//		Actor actorUpdate = new Actor();
//		actorUpdate.setFirstName("Andrew");
//		actorUpdate.setLastName("Conlinnnnn");
//		actorUpdate = actorDAO.update(201,actorUpdate);
//		System.out.println(actorUpdate);

		// remove
//		boolean result = actorDAO.destroy(201);
//		System.out.println(result);
		
		// create actor and film
//		Actor a = new Actor();
//		a.setFirstName("Chuck");
//		a.setLastName("Norris");
//		Film f = new Film();
//		f.setTitle("Hellbound");
//		f.setRentalRate(12.34);
//		f.setReplacementCost(100.00);
//		
//		a = actorDAO.createActorAndFilm(a, f);
//		
//		System.out.println(a);
//		System.out.println(a.getFilms().get(0));

	}
}

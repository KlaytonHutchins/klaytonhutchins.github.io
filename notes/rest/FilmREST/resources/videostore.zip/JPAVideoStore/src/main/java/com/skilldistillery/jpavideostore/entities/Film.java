package com.skilldistillery.jpavideostore.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Film {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String title;
	
	private String description;
	
	@Column(name="release_year")
	private int releaseYear;
	
	@Column(name="rental_rate")
	private double rentalRate;
	
	private int length;
	
	@Column(name="replacement_cost")
	private double replacementCost;
	
	@Enumerated(EnumType.STRING)
	private Rating rating;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="language_id")
	private Language language;

	@JsonIgnore
	@ManyToMany
	@JoinTable(name="film_actor",
	  joinColumns=@JoinColumn(name="film_id"),
	  inverseJoinColumns=@JoinColumn(name="actor_id")
	)
	private List<Actor> actors;
	
	@JsonIgnore
	@ManyToMany
	@JoinTable(name="film_category",
	joinColumns=@JoinColumn(name="film_id"),
	inverseJoinColumns=@JoinColumn(name="category_id")
			)
	private List<Category> categories;
	
	@JsonIgnore
	@ManyToMany
	@JoinTable(name="inventory_item",
	joinColumns=@JoinColumn(name="film_id"),
	inverseJoinColumns=@JoinColumn(name="store_id")
			)
	private List<Store> stores;
	
	@JsonIgnore
	@OneToMany(mappedBy="film")
	private List<InventoryItem> copies;
	
	// gets and sets
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getReleaseYear() {
		return releaseYear;
	}

	public void setReleaseYear(int releaseYear) {
		this.releaseYear = releaseYear;
	}

	public double getRentalRate() {
		return rentalRate;
	}

	public void setRentalRate(double rentalRate) {
		this.rentalRate = rentalRate;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public double getReplacementCost() {
		return replacementCost;
	}

	public void setReplacementCost(double replacementCost) {
		this.replacementCost = replacementCost;
	}

	public Rating getRating() {
		return rating;
	}

	public void setRating(Rating rating) {
		this.rating = rating;
	}

	public Language getLanguage() {
		return language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}

	public List<Actor> getActors() {
		return actors;
	}

	public void setActors(List<Actor> actors) {
		this.actors = actors;
	}
	
	// add and remove from collections
	
	public List<Store> getStores() {
		return stores;
	}

	public void setStores(List<Store> stores) {
		this.stores = stores;
	}

	public List<InventoryItem> getCopies() {
		return copies;
	}

	public void setCopies(List<InventoryItem> copies) {
		this.copies = copies;
	}

	public void addActor(Actor a) {
		if(actors == null) actors = new ArrayList<>();
		
		if(!actors.contains(a)) {
			actors.add(a);
			a.addFilm(this);
		}
	}
	
	public void removeActor(Actor a) {
		if(actors != null && actors.contains(a)) {
			actors.remove(a);
			a.removeFilm(this);
		}
	}
	
	public void addCategory(Category c) {
		if(categories == null) categories = new ArrayList<>();
		
		if(!categories.contains(c)) {
			categories.add(c);
			c.addFilm(this);
		}
	}
	
	public void removeCategory(Category c) {
		if(categories != null && categories.contains(c)) {
			categories.remove(c);
			c.removeFilm(this);
		}
	}
	
	public void addStore(Store s) {
		if(stores == null) stores = new ArrayList<>();
		
		if(!stores.contains(s)) {
			stores.add(s);
			s.addFilm(this);
		}
	}
	
	public void removeStore(Store s) {
		if(stores != null && stores.contains(s)) {
			stores.remove(s);
			s.removeFilm(this);
		}
	}
	
	public void addInvItem(InventoryItem i) {
		if(copies == null) copies= new ArrayList<>();
		
		if(!copies.contains(i)) {
			copies.add(i);
			if(i.getFilm() != null) {
				i.getFilm().getCopies().remove(i);
			}
			i.setFilm(this);
		}
	}
	
	public void removeImvItem(InventoryItem i) {
		i.setFilm(null);
		if(copies != null) {
			copies.remove(i);
		}
	}
	// toString
//	@Override
//	public String toString() {
//		return "Film [id=" + id + ", title=" + title + ", description=" + description + ", releaseYear=" + releaseYear
//				+ ", rentalRate=" + rentalRate + ", length=" + length + ", replacementCost=" + replacementCost + "]";
//	}
	
	
}

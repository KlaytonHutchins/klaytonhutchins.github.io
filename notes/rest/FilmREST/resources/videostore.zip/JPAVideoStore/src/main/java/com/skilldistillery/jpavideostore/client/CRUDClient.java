package com.skilldistillery.jpavideostore.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.skilldistillery.jpavideostore.entities.Address;
import com.skilldistillery.jpavideostore.entities.Customer;

public class CRUDClient {
	public static void main(String[] args) {
		CRUDClient crud = new CRUDClient();
		//crud.updateNullEmails();	   // #2
		//crud.addNewAddress();         // #3
		//crud.deleteAddreses();		   // #4
	}
	
	public void updateNullEmails() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();
		
		String query = "SELECT c FROM Customer c WHERE c.email=''";
		
		List<Customer> results = em.createQuery(query, Customer.class)
				.getResultList();
		
		em.getTransaction().begin();
		
		for (Customer customer : results) {
			customer.setEmail(customer.getFirstName() + "." + customer.getLastName()+"@sdcustomer.org");
		}
		
		em.getTransaction().commit();

		em.close();
		emf.close();
	}
	
	public void addNewAddress() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();
		
		Address address = new Address();
		address.setStreet("7200 E. Orchard");
		address.setCity("Greenwood Village");
		address.setState("Colorado");
		address.setPostalCode("80210");
		address.setPhone("(303) 302-5234");
		
		em.getTransaction().begin();
		
		em.persist(address);
		em.flush();
		
		em.getTransaction().commit();
		
		System.out.println(address);

		em.close();
		emf.close();
	}
	
	public void deleteAddreses() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();
		
		
		em.getTransaction().begin();
		
		try {
			Address address = em.find(Address.class, 734);
			em.remove(address);
			em.getTransaction().commit();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		em.close();
		emf.close();
	}
}

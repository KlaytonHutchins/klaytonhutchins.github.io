package com.skilldistillery.jpavideostore.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Store {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	
	@OneToOne
	@JoinColumn(name="address_id")
	private Address address;
	
	@OneToMany(mappedBy="store")
	private List<Customer> customers;
	
	@OneToMany(mappedBy="store")
	private List<Staff> staffMembers;
	
	@OneToOne
	@JoinColumn(name="manager_id")
	private Staff manager;
	
	@ManyToMany(mappedBy="stores")
	private List<Film> films;
	
	@OneToMany(mappedBy="store")
	private List<InventoryItem> copies;

	// gets and sets
	public int getId() {
		return id;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}
	
	public List<Staff> getStaffMembers() {
		return staffMembers;
	}

	public void setStaffMembers(List<Staff> staffMembers) {
		this.staffMembers = staffMembers;
	}

	public Staff getManager() {
		return manager;
	}

	public void setManager(Staff manager) {
		this.manager = manager;
	}

	public List<Film> getFilms() {
		return films;
	}

	public void setFilms(List<Film> films) {
		this.films = films;
	}

	public List<InventoryItem> getCopies() {
		return copies;
	}

	public void setCopies(List<InventoryItem> copies) {
		this.copies = copies;
	}

	// add and remove from collections
	public void addCustomer(Customer c) {
		if(customers == null) customers= new ArrayList<>();
		
		if(!customers.contains(c)) {
			customers.add(c);
			if(c.getStore() != null) {
				c.getStore().getCustomers().remove(c);
			}
			c.setStore(this);
		}
	}

	public void removeCustomer(Customer c) {
		c.setStore(null);
		if(customers != null) {
			customers.remove(c);
		}
	}
	
	public void addStaffMember(Staff s) {
		if(staffMembers == null) staffMembers= new ArrayList<>();
		
		if(!staffMembers.contains(s)) {
			staffMembers.add(s);
			if(s.getStore() != null) {
				s.getStore().getStaffMembers().remove(s);
			}
			s.setStore(this);
		}
	}

	public void removeStaffmember(Staff s) {
		s.setStore(null);
		if(staffMembers != null) {
			staffMembers.remove(s);
		}
	}

	public void addFilm(Film f) {
		if(films == null) films = new ArrayList<>();
		
		if(!films.contains(f)) {
			films.add(f);
			f.addStore(this);
		}
	}
	
	public void removeFilm(Film f) {
		if(films != null && films.contains(f)) {
			films.remove(f);
			f.removeStore(this);
		}
	}
	
	public void addInvItem(InventoryItem i) {
		if(copies == null) copies= new ArrayList<>();
		
		if(!copies.contains(i)) {
			copies.add(i);
			if(i.getStore() != null) {
				i.getStore().getCopies().remove(i);
			}
			i.setStore(this);
		}
	}
	
	public void removeImvItem(InventoryItem i) {
		i.setStore(null);
		if(copies != null) {
			copies.remove(i);
		}
	}
	
	// toString
	@Override
	public String toString() {
		return "Store [id=" + id + ", address=" + address + "]";
	}

	
	
}

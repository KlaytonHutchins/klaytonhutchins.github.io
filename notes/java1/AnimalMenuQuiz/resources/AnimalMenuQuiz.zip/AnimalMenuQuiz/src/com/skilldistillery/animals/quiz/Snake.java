package com.skilldistillery.animals.quiz;

public class Snake extends Animal {

  public Snake(String name) {
    super(name);
  }

  @Override
  public void makeNoise() {
    System.out.println("Slither, slither...");
  }

}

package com.skilldistillery.animals.quiz;

public abstract class Animal {
  private String name;
  
  public Animal(String name) {
    this.name = name;
  }

  public abstract void makeNoise();
  
  public void eat(int poundsOfFood) {
    System.out.println(name + " the " + getClass().getSimpleName() 
        + " is eating " + poundsOfFood + " food.");
  }
}

package com.skilldistillery.animals.quiz;

import java.util.Scanner;

public class AnimalsApp {

  public static void main(String[] args) {
    AnimalsApp app = new AnimalsApp();
    app.run();
  }

  /*
   * REQUIREMENT 1 --------- In the method below, display a menu that reads:
   * 
   * 
   Options:
   
   1. Feed the Lion 
   2. Feed the Snake
   3. Feed the Bald Eagle 
   4. Have all animals make noise
   5. Exit
   
   * 
   */
  private void displayMenu() {
    
  }

  private void run() {
    Scanner sc = new Scanner(System.in);

    // REQUIREMENT 2 ---------
    // instantiate the animals array with space for three Animals.
    Animal[] animals;

    // REQUIREMENT 3 ---------
    // Assign a new Lion to index 0
    // Assign a new Snake to index 1
    // Assign a new BaldEagle to index 2
    
    int userInput = 5;
    do {
      // Display the Menu - you must complete the displayMenu() method
      displayMenu();
  
      // REQUIREMENT 4 ---------
      // Prompt the user for input, and accept that integer input
      
      // REQUIREMENT 5 ---------
      // For the following user input, call the correct methods
      // 1 - Feed the Lion 10 pounds of food by calling the feedAnimal method
      // 2 - Feed the Snake 2 pounds of food by calling the feedAnimal method
      // 3 - Feed the Bald Eagle 4 pounds of food by calling the feedAnimal method
      // 4 - call allMakeNoise, passing in the animals array
      // 5 - Print "Goodbye." to the screen
     
    } while(userInput != 5);
    sc.close();
  }

  /*
   * REQUIREMENT 6 --------- Create the following method
   * 
   * visibility:      protected 
   * return type:     void 
   * name:            allMakeNoise 
   * parameter:       Animal[] animals
   * 
   * functionality: loop through the input array and call makeNoise() for each
   * animal
   * 
   * 
   */

  // YOUR METHOD GOES HERE
  

  private void feedAnimal(Animal a, int poundsOfFood) {
    a.eat(poundsOfFood);
  }

}

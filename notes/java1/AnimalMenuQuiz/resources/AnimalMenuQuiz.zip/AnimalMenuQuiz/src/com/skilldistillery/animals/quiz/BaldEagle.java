package com.skilldistillery.animals.quiz;

public class BaldEagle extends Animal {

  public BaldEagle(String name) {
    super(name);
  }

  @Override
  public void makeNoise() {
    System.out.println("Screeech, 'Merica!");
  }

}

package com.skilldistillery.superclasses.drills;

import com.skilldistillery.superclasses.drills.Employee;

public class DataAnalyst extends Employee {
  private String securityClearance;
  
  public DataAnalyst(String securityClearance, String firstName, String lastName, int age, String title, double salary) {
    this.setSecurityClearance(securityClearance);
    this.setFirstName(firstName);
    this.setLastName(lastName);
    this.setAge(age);
    this.setTitle(title);
    this.setSalary(salary);
  }

  public String getSecurityClearance() {
    return securityClearance;
  }

  public void setSecurityClearance(String securityClearance) {
    this.securityClearance = securityClearance;
  }

  public String getInfo() {
    return getName() + " " + age                    // protected in Person
        + " " + getTitle() + " " + getSalary()      // visible methods from Employee
        + " " + securityClearance;                  // private in DataAnalyst
  }
}

package com.skilldistillery.superclasses.solutions;

import com.skilldistillery.superclasses.drills.Employee;

public class DataAnalyst3 extends Employee {
  private String securityClearance;
  
  public DataAnalyst3(String securityClearance, String firstName, String lastName, int age, String title, double salary) {
    this.setSecurityClearance(securityClearance);
    this.setFirstName(firstName);
    this.setLastName(lastName);
    this.setAge(age);
    this.setTitle(title);
    this.setSalary(salary);
  }

  public String getSecurityClearance() {
    return securityClearance;
  }

  public void setSecurityClearance(String securityClearance) {
    this.securityClearance = securityClearance;
  }

  // Call the parent method
  public String getInfo() {
    return super.getInfo() + " " + securityClearance;
  }
}

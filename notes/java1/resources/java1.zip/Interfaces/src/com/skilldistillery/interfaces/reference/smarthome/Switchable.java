package com.skilldistillery.interfaces.reference.smarthome;
public interface Switchable {
  void turnOn();
  void turnOff();
  boolean isOn();
}


//public abstract interface Switchable {
//  public abstract void turnOn();
//  abstract public void turnOff();
//  public abstract boolean isOn();
//}

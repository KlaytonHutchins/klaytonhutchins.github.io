package com.skilldistillery.characters.solutions;

public class UnicodeOutput {

  public static void main(String[] args) {
    // Write the characters 
    // '\u261d', '\u270a', '\u270b', '\u270c' 
    // to the screen.
    System.out.println('\u261d' + "" + '\u270a' + "" + '\u270b' + "" + '\u270c');
  }

}

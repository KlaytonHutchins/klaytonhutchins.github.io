package com.skilldistillery.characters.drills;

public class UnicodeOutput {

  public static void main(String[] args) {
    // Write the characters 
    // '\u261d', '\u270a', '\u270b', '\u270c' 
    // to the screen.
    

  }

}

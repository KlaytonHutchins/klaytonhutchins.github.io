package com.skilldistillery.unittesting.solutions;

import org.junit.Test;

public class TextConverterTests2 {
  @Test
  public void test_toCaps_returns_null_for_null_input() {
    
  }
  
  @Test
  public void test_toCaps_returns_all_caps_version_of_input() {
    
  }
  
  @Test
  public void test_removeOuterWhitespace_returns_null_for_null_input() {
    
  }
  
  @Test
  public void test_removeOuterWhitespace_returns_String_with_outer_whitespace_removed() {
    
  }
  
  @Test
  public void test_removeOuterWhitespace_returns_String_with_inner_whitespace_intact() {
    
  }
  
  @Test
  public void test_concatStrings_returns_null_for_null_input() {
    
  }
  
  @Test 
  public void test_concatStrings_returns_empty_String_for_no_input() {
    
  }
  
  @Test
  public void test_concatStrings_returns_empty_String_for_empty_String_input() {
    
  }
  
  @Test
  public void test_concatStrings_returns_single_String_same_length_as_input() {
    
  }
  
  @Test
  public void test_concatStrings_returns_two_Strings_concatenated_without_extra_whitespace() {
    
  }
  
  @Test
  public void test_concatStrings_returns_two_Strings_concatenated_with_whitespace_intact() {
    
  }
}

package com.skilldistillery.polymorphism.drills;

public class ValidOverrides extends ValidOverridesBaseClass {
  // //1 *******
  // //Comments:
  // @Override
  // public void method1(String input) { }

  // //2 *******
  // //Comments:
  // @Override
  // public String method2() { return null; }
  
  // //3 *******
  // //Comments:
  // @Override
  // public String method3(Object s) { return null;}
  
  // //4 *******
  // //Comments: 
  // @Override
  // public Object method4(Object s) { return null;}
  
  // //5 *******
  // //Comments: 
  // @Override
  // void method5(String s) {  }
  
  // //6 *******
  // //Comments: 
  // public String method6() { return null; }
  
  // //7 *******
  // //Comments: 
  // public int method7() { return 1; }
  
  // //8 *******
  // //Comments: 
  // @Override
  // public static int method8() { return 1; }
  
  // //9 *******
  // //Comments: 
  // public void method9() { }
  
  // //10 ******
  // //Comments: 
  // @Override
  // public void method10(int b, String a) { }
}

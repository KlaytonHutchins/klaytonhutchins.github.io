package com.skilldistillery.polymorphism.drills.employee;

public class EmployeePrintingApp {

  public static void main(String[] args) {
    EmployeePrintingApp epa = new EmployeePrintingApp();
    
    epa.run();

  }
  
  private void run() {
    // Create an array of type Employee with space for 3 Employees
    
    // Create a DataAnalyst, SoftwareDeveloper, and DatabaseAdmin
    // using the multi-arg constructors for each, and assign each to the array.
    
    // Call processEmployees and pass the Employee array reference.
  }
  
  // Add a method printEmployeeNameAndTitle that takes an Employee and prints
  // name - title
  // to the screen.
  
  public void processEmployees(Employee[] employees) {
    // loop through the Employee array and call printEmployeeNameAndTitle
    // for each Employee
  }

}

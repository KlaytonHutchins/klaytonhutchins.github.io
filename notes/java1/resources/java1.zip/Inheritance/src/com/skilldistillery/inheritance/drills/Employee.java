package com.skilldistillery.inheritance.drills;

public class Employee  {
  
}

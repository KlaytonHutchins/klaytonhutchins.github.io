package com.skilldistillery.wrapperclasses.solutions;

import java.util.Scanner;

public class CountUpOrDown {

  public static void main(String[] args) {

    Scanner input = new Scanner(System.in);

    System.out.print("Please enter a whole number: ");
    int count = input.nextInt();
    System.out.print("Please enter true or false: ");
    boolean b = input.nextBoolean();
    
    if (b) {
      for (int i = 0; i <= count; i++) {
        System.out.println(i);
      }
    }
    else {
      for (int i = count; i >= 0; i--) {
        System.out.println(i);
      }      
    }

    input.close();
  }

}

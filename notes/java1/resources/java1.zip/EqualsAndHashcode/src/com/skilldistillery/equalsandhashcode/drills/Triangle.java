package com.skilldistillery.equalsandhashcode.drills;

public class Triangle {
  private int base;
  private int height;
  
  public Triangle(int b, int h) {
    this.base = b;
    this.height = h;
  }

}

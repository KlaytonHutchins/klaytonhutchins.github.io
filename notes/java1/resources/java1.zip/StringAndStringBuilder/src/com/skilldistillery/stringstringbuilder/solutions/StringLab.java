package com.skilldistillery.stringstringbuilder.solutions;

public class StringLab {

  public static void main(String[] args) {
    StringLab lab = new StringLab();
    lab.go();
  }

  private void go() {
      // Using String methods, determine and print whether 'testString':
      // 1. Starts with 'abc'
      // 2. Ends with 'ld!'
      // 3. Contains 'wor'
      String testString = "Hello world!";

      //1
      System.out.println(testString.startsWith("abc"));
      //2
      System.out.println(testString.endsWith("ld!"));
      //3
      System.out.println(testString.contains("wor"));

      // Using String methods, print the following information
      // about 'testString2':
      // 1. The character at index 3
      // 2. The amount of characters in the String
      // 3. The contents of the String in all uppercase
      // 4. The contents of the String without white space on either StringBuilder

      String testString2 = "   Hello Java Coding World!   ";

      //1
      System.out.println(testString2.charAt(3));
      //2
      System.out.println(testString2.length());
      //3
      System.out.println(testString2.toUpperCase());
      //4
      System.out.println(testString2.trim());

  }

}

package com.skilldistillery.stringstringbuilder.labs;

public class StringLab {

  public static void main(String[] args) {
    StringLab lab = new StringLab();
    lab.go();
  }

  private void go() {
      // Using String methods, determine and print whether 'testString':
      // 1. Starts with 'abc'
      // 2. Ends with 'ld!'
      // 3. Contains 'wor'
      String testString = "Hello world!";


      // Using String methods, print the following information
      // about 'testString2':
      // 1. The character at index 3
      // 2. The number of characters in the String
      // 3. The contents of the String in all uppercase
      // 4. The contents of the String without white space on either side

      String testString2 = "   Hello Java Coding World!   ";


  }

}

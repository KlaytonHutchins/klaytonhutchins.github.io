package com.skilldistillery;

public class Helper {
  public static void helperMethod() {}
}

package com.skilldistillery.entities;

public class Store {
	// TODO: each store has an id
	
	// TODO: each store has 0 or more unique Customers
	
	// TODO: implement the required methods to:
	//       * Add a customer (no duplicates allowed)
	//       * Return the number of customers
	//       * Display all data
}

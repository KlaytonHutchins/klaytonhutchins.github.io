package com.skilldistillery.mapinterface.drills;

public class UsingHashMap {

  public static void main(String[] args) {
    UsingHashMap uhm = new UsingHashMap();
    uhm.launch();
  }

  private void launch() {
    // Declare and instantiate a map to hold Integer--->String key-value pairs
    
    // Put these pairs in the map
    // 1  George Washington
    // 16 Abraham Lincoln
    // 32 Franklin D. Roosevelt
    // 36 Lyndon B. Johnson
    // 44 Barack Obama
    
    // Get the value for key 16 and output the key and value to the screen
    
    // Get the value for key 37 and output the key and value to the screen
    
    // Get the value for key 36 and output the key and value to the screen.
    
    // Iterate through the Map and output the key-value pairs in the format
    // key[tab][tab]value
    
    
  }

}

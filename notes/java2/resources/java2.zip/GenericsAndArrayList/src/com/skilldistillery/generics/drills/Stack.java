package com.skilldistillery.generics.drills;

/**
 * Note: this Stack implementation has an issue, in that we could add nulls, but we also 
 * return null for an empty list. We will have to live with this. 
 * 
 */
public class Stack {
  
  public Stack() {
  }
  
  public Object push(Object item) {
    
    return null;
  }
  
  public Object pop() {
    
    return null;
  }
  
  public Object peek() {
    
    return null;
  }
  
  public int search(Object o) {
    return -1;
  }
}

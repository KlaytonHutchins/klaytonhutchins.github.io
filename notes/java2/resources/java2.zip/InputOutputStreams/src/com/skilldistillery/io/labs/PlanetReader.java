package com.skilldistillery.io.labs;

public class PlanetReader {

  public static void main(String[] args) {
    String fileName = "planets.txt";
    PlanetReader pr = new PlanetReader();
    pr.readPlanets(fileName);
  }

  private void readPlanets(String fileName) {
    // Add code here to:
    // Open the file
    // Read it line by line, printing just the planet name.
    // Close the file.
  }

}

package com.skilldistillery.io.examples;

public class EmployeeReaderExample {
  public static void main(String[] args) {
    EmployeeReaderExample ere = new EmployeeReaderExample();
    ere.readTheFile("employee.txt");
  }

  private void readTheFile(String string) {
    // TODO Auto-generated method stub
    
  }

}

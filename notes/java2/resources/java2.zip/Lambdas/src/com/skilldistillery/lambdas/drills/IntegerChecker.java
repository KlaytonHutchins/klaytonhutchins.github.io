package com.skilldistillery.lambdas.drills;

public interface IntegerChecker {
  boolean test(Integer i);
}

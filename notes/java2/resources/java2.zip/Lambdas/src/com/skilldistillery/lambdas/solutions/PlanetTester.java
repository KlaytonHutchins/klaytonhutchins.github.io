package com.skilldistillery.lambdas.solutions;

public interface PlanetTester {
  public boolean test(Planet p);
}

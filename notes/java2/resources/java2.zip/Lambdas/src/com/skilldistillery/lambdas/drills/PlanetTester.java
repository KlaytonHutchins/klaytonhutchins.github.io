package com.skilldistillery.lambdas.drills;

public interface PlanetTester {
  public boolean test(Planet p);
}

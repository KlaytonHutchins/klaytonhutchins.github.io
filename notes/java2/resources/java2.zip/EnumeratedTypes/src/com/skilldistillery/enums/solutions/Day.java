package com.skilldistillery.enums.solutions;

public enum Day {
    SUNDAY, 
    MONDAY, 
    TUESDAY, 
    WEDNESDAY,
    THURSDAY, 
    FRIDAY, 
    SATURDAY 
}

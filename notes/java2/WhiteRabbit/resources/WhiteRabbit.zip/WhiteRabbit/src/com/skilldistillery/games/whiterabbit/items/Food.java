package com.skilldistillery.games.whiterabbit.items;

import com.skilldistillery.games.whiterabbit.GameCharacter;

public abstract class Food implements GameItem {
  
  private String name;
  private double alterationFactor;

  
  public Food(String name, double alterationFactor) {
    super();
    this.name = name;
    this.alterationFactor = alterationFactor;
  }

  public String getName() {
    return name;
  }

  public double getAlterationFactor() {
    return alterationFactor;  // percentage
  }

  @Override
  public void alterGameCharacter(GameCharacter c) {
    // TODO:
    // change the character's height based on this object's alterationFactor
    
    // if the character's height ends up 0, set it to 1.
  }

}

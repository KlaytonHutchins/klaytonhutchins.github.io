package com.skilldistillery.games.whiterabbit;

import com.skilldistillery.games.whiterabbit.items.GameItem;

public class GameCharacter {
  private String name;
  private int height;
  
  public GameCharacter(String name, int height) {
    super();
    this.name = name;
    this.height = height;
  }

  public int getHeight() {
    return height;
  }

  public void setHeight(int height) {
    this.height = height;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
  
  public void useItem(GameItem item) {
    item.alterGameCharacter(this);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder(64)
        .append("You are ")
        .append(name)
        .append(" and your height is ")
        .append(height)
        .append(".");
    return sb.toString();
  }
}

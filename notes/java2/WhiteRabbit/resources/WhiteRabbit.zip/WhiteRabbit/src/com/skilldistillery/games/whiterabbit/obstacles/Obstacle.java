package com.skilldistillery.games.whiterabbit.obstacles;

public class Obstacle {
  private int height;
  private String name;
  private String type; // BIG, SMALL

  public static final String TYPE_BIG = "BIG";
  public static final String TYPE_SMALL = "SMALL";

  public Obstacle(String name, int height, String type) {
    super();
    this.name = name;
    this.height = height;
    this.type = type;
  }

  public String getName() {
    return name;
  }

  public String getType() {
    return type;
  }

  public int getHeight() {
    return height;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append(name);
    builder.append(" which appears to be ");
    builder.append(height);
    builder.append(" ");
    builder.append(type);
    return builder.toString();
  }

}
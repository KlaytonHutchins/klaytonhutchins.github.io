package com.skilldistillery.games.whiterabbit.items;

import com.skilldistillery.games.whiterabbit.GameCharacter;

public interface GameItem {
  void alterGameCharacter(GameCharacter c);
}
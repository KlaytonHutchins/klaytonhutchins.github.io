package com.skilldistillery.madlibs.io.story;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.skilldistillery.madlibs.io.story.FileStorySource;

public class FileStorySourceTests {
  private StorySource source;
  
  @Before
  public void setUp() {
    source = new FileStorySource("tests/teststory.txt");
  }
  
  @After
  public void tearDown() {
    source = null;
  }
  
  @Test
  public void test_ctor_and_getLines_has_all_lines() {
    List<String> lines = source.getLines();
    assertNotNull(lines);
    assertEquals(4, lines.size());
  }
}

package com.skilldistillery.madlibs.io.wordsource;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.skilldistillery.madlibs.TextLabels;

public class FileWordSourceTests {

  private WordSource source;
  
  @Before
  public void setUp() {
    Map<String, String> tokensAndFilenames = new HashMap<>();
    tokensAndFilenames.put(TextLabels.PREPOSITION, "prepositions.txt");
    source = new FileWordSource(tokensAndFilenames);
  }
  
  @After
  public void tearDown() {
    source = null;
  }
  
  @Test
  public void test_getWordsFromSource_gets_list_using_placeholder_and_contains_all_text() {
    Map<String, List<String>> map = source.getWordsFromSource();
    
    assertNotNull(map);
    assertEquals(1, map.keySet().size());
    
    List<String> words = map.get(map.keySet().iterator().next());
    assertEquals(15, words.size());
  }
  
}

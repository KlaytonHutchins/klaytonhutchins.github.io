package com.skilldistillery.madlibs.io.wordsource;

import java.util.List;
import java.util.Map;

public interface WordSource {

  Map<String, List<String>> getWordsFromSource();

}
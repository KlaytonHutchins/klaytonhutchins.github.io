package com.skilldistillery.madlibs.io.wordsource;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.skilldistillery.madlibs.TextLabels;
import com.skilldistillery.madlibs.io.FileSource;

public class FileWordSource implements FileSource, WordSource {
  private static final String FILE_DIRECTORY = "resources";
  private Map<String, String> tokensAndFilenames;

  public FileWordSource() {
    tokensAndFilenames = new HashMap<>();
    tokensAndFilenames.put(TextLabels.ADJECTIVE, FILE_DIRECTORY + File.separator + "adjectives.txt");
    tokensAndFilenames.put(TextLabels.ADVERB, FILE_DIRECTORY + File.separator + "adverbs.txt");
    tokensAndFilenames.put(TextLabels.CONJUNCTION, FILE_DIRECTORY + File.separator + "conjunctions.txt");
    tokensAndFilenames.put(TextLabels.INTERJECTION, FILE_DIRECTORY + File.separator + "interjections.txt");
    tokensAndFilenames.put(TextLabels.NOUN, FILE_DIRECTORY + File.separator + "nouns.txt");
    tokensAndFilenames.put(TextLabels.PLURAL, FILE_DIRECTORY + File.separator + "plurals.txt");
    tokensAndFilenames.put(TextLabels.PREPOSITION, FILE_DIRECTORY + File.separator + "prepositions.txt");
    tokensAndFilenames.put(TextLabels.PRONOUN, FILE_DIRECTORY + File.separator + "pronouns.txt");
    tokensAndFilenames.put(TextLabels.VERB, FILE_DIRECTORY + File.separator + "verbs.txt");
  }
  
  public FileWordSource(Map<String, String> tokensAndFilenames) {
    this.tokensAndFilenames = tokensAndFilenames;
  }
  
  @Override
  public Map<String, List<String>> getWordsFromSource(){
    Map<String, List<String>> map = new HashMap<String, List<String>>();

    // Task: Retrieve each placeholder key from the tokensAndFilenames HashMap.
    //       Pass the associated filename to readFileForData to retrieve the
    //       word list for that placeholder.
    //       Put the key and the list into map.
    
    return map;
  }
  
}

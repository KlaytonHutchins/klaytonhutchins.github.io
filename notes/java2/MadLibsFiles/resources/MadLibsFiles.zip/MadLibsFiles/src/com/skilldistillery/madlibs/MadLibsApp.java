package com.skilldistillery.madlibs;

import java.util.List;
import java.util.Map;

import com.skilldistillery.madlibs.io.story.FileStorySource;
import com.skilldistillery.madlibs.io.story.StorySource;
import com.skilldistillery.madlibs.io.wordsource.FileWordSource;
import com.skilldistillery.madlibs.io.wordsource.WordSource;

public class MadLibsApp {
  
  private SubstitutionEngine subEngine = new SimpleSubstitutionEngine();
  private WordSource wordSource = new FileWordSource();
  private StorySource story = new FileStorySource("story.txt");
  
  public static void main(String[] args) {
    MadLibsApp app = new MadLibsApp();
    app.launch();
  }

  private void launch() {
    // read story file
    List<String> lines = story.getLines();
    
    Map<String, List<String>> wordsFromSource = wordSource.getWordsFromSource();
    
    // sub words into file data
    List<String> substitution = doSubstitution(lines, wordsFromSource);
    
    printLinesToScreen(substitution);
  }
  
  private void printLinesToScreen(List<String> lines) {
    for (String string : lines) {
      System.out.println(string);
    }
  }
  
  private List<String> doSubstitution(List<String> lines, Map<String, List<String>> words){
    return subEngine.doSubstitution(lines, words);
  }
}

package com.skilldistillery.madlibs.io.story;

import java.io.File;
import java.util.List;

import com.skilldistillery.madlibs.io.FileSource;

public class FileStorySource implements FileSource, StorySource {
  private static final String FILE_DIRECTORY = "resources";
  List<String> lines;
  private String filename;
  
  public FileStorySource() {
    this("story.txt");
  }
  
  public FileStorySource(String filename) {
    this.filename = FILE_DIRECTORY + File.separator + filename;
    lines = readFileForData(this.filename);
  }
  
  @Override
  public List<String> getLines(){
    return lines;
  }
}

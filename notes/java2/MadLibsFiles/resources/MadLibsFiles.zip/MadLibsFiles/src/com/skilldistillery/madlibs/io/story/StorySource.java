package com.skilldistillery.madlibs.io.story;

import java.util.List;

public interface StorySource {

  List<String> getLines();

}
package com.skilldistillery.madlibs;

import java.util.List;
import java.util.Map;

public interface SubstitutionEngine {

  List<String> doSubstitution(List<String> lines, Map<String, List<String>> words);

}
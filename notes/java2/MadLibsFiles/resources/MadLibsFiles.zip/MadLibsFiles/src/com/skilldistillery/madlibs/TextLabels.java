package com.skilldistillery.madlibs;

public class TextLabels {
  public static final String NOUN = "%%NOUN%%";
  public static final String PLURAL = "%%PLURAL%%";
  public static final String PRONOUN = "%%PRONOUN%%";
  public static final String PREPOSITION = "%%PREPOSITION%%";
  public static final String INTERJECTION = "%%INTERJECTION%%";
  public static final String VERB = "%%VERB%%";
  public static final String ADJECTIVE = "%%ADJECTIVE%%";
  public static final String ADVERB = "%%ADVERB%%";
  public static final String CONJUNCTION = "%%CONJUNCTION%%";
}

package com.skilldistillery.madlibs.io;

import java.util.ArrayList;
import java.util.List;

public abstract interface FileSource {
  default List<String> readFileForData(String fileName){
    List<String> list = new ArrayList<>();

    // Task: Open the file fileName, read each line and add it to the list.

    
    return list;
  }
}

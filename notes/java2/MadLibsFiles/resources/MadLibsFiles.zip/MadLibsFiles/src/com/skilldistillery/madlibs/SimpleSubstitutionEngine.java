package com.skilldistillery.madlibs;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SimpleSubstitutionEngine implements SubstitutionEngine {

  @Override
  public List<String> doSubstitution(List<String> lines, Map<String, List<String>> words) {
    return doSubstitutionIndexOf(lines, words);
  }

  private List<String> doSubstitutionIndexOf(List<String> lines, Map<String, List<String>> words) {
    List<String> sub = new ArrayList<>(lines.size());

    // Task: In each line of the lines List, find and replace each placeholder
    //       with a word selected randomly from the word list for that placeholder
    
    return sub;
  }

}

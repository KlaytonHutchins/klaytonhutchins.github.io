
public class LetterHouse {
	public static void main(String[] args) {
		printRoof(); 
		printFloor();
	}

	static void printRoof() {
		System.out.println("                  EEEE");
		System.out.println("        BBBBBBBB  E  E");
		System.out.println("      B          BE  E");
		System.out.println("    B               BE");
		System.out.println("  B                   B");
		System.out.println("B                       B");
	}

	static void printFloor() {
		System.out.println(" G  GGGG         GGGG  G");
		System.out.println(" G  G  G  EEEEE  G  G  G");
		System.out.println(" G  GGGG  E   E  GGGG  G");
		System.out.println(" G        E  EE        G");
		System.out.println(" G        E   E        G");
		System.out.println(" GGGGGGGGGGGGGGGGGGGGGGG");
	}
}

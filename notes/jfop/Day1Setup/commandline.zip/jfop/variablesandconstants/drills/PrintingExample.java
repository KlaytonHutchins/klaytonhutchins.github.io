
public class PrintingExample {

	public static void main(String[] args) {
		int i_5 = 5;
		double d_5 = 5.00001;
		char c_5 = '5';

		System.out.println("int 5: " + i_5);
		System.out.println("double 5: " + d_5);
		System.out.println("char 5: " + c_5);
	}

}

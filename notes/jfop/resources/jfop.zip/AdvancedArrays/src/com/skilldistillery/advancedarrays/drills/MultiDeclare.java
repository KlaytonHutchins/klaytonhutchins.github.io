package com.skilldistillery.advancedarrays.drills;

public class MultiDeclare {
  public static void main(String[] args) {
    // Declare a two-dimensional array of char values to represent a 
    // tic-tac-toe board.
    
    // Assign the value 'X' to the top-left, middle, and bottom-right squares.
    // X  
    //  X 
    //   X
    
    // Assign the value 'O' (capital 'o') to the three squares bottom-left.
    // X  
    // OX 
    // OOX
    
    // Assign the value '*' to the remaining squares.
    // X**  
    // OX*
    // OOX
  }
}

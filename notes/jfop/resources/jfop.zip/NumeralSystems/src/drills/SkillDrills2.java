package drills;

public class SkillDrills2 {

  public static void main(String[] args) {
    
//    int i1 = 678; 
//    int i2 = 0678; 
//    int i3 = 0x678; 
//    int i4 = 01101; 
//    int i5 = 0b1101; 
//    int i6 = 0x01101; 
//    int i7 = 1101; 
//    int i8 = 0x12; 
//    int i9 = 0b12; 
//    int ia = 0xb2; 
//    int ib = 0bx2; 
//    int ic = 0b_101_111_111; 
//    int id = 0xb10_000; 
//    int ie = 0b10_000; 
//    int if_ = 0xCAFE_BABE; 
    
//    double d1 = 123.456; 
//    double d2 = 1.235_56; 
//    double d43 = 123._456; 

  }

}

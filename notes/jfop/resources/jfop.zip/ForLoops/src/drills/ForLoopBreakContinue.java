package drills;

public class ForLoopBreakContinue {

  public static void main(String[] args) {
    // Try the loops in the examples above in code.
    System.out.println("Loop 1...");
    // COPY-PASTE LOOP 1 HERE

    System.out.println("Loop 2...");
    // COPY-PASTE LOOP 2 HERE

    System.out.println("Loop 3...");
    // Write a loop that prints the numbers from 1 to 30, skipping
    // multiples of 3.
  }

}


public class BigLetters {
  public static void main(String[] args) {
    System.out.println(" GGGGG  EEEEEEE BBBBBB");
    System.out.println("G       E       B     B");
    System.out.println("G       E       B     B");
    System.out.println("G  GGG  EEEEE   BBBBBB");
    System.out.println("G     G E       B     B");
    System.out.println("G     G E       B     B");
    System.out.println(" GGGGG  EEEEEEE BBBBBB "); 
  }
}

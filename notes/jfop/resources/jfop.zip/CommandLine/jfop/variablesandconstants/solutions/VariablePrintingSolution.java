
public class VariablePrintingSolution {

	public static void main(String[] args) {
		double battingAverage = .345;
		double thisYearBA = battingAverage;
		battingAverage = .362; //reassignment
		
		System.out.println("battingAverage is " + battingAverage);
		System.out.println("thisYearBA is " + thisYearBA);
		
		// Add Strings to the System.out.println() statements to display which variable is being output
		
	}

}

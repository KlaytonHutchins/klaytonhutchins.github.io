
public class VariableNaming {

	public static void main(String[] args) {
		//Declare a variable of type int for the distance something (a car, a rocket) traveled.
		
		//Declare a variable of type int for the distance between the center of a circle and its edge.
		
		//Declare a variable of type String for a user's full name;

	}

}
